package com.flip.model;

public enum Gender {

	MALE,
	FEMALE
}
